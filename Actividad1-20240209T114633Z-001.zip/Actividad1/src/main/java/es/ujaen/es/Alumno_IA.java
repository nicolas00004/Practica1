package es.ujaen.es;
import java.util.Scanner;
public class Alumno_IA  extends Alumno {
    private String grupoT, grupoP;
    private Practicas[] pra;

    public Alumno_IA(){
        this.pra=new Practicas[4];
        for(int i =1;i<pra.length+1;i++){
            pra[i].setId_pra(i);
        }
    }
    public String getGrupoT() {
        return grupoT;
    }

    public void setGrupoT(String grupoT) {
        this.grupoT = grupoT;
    }

    public String getGrupoP() {
        return grupoP;
    }

    public void setGrupoP(String grupoP) {
        this.grupoP = grupoP;
    }

    public void  nota_pra_te(){//Leer desde teclado las 4 notas de practicas de un alumno de IA
        Scanner scanner =new Scanner(System.in);
        System.out.println("Inserte las notas de la practica:");
        for (int i = 1; i <pra.length+1; i++) {
            System.out.println("1: ");
            this.pra[i].setNota(scanner.nextInt());
        }
    }
}