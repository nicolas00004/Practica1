package es.ujaen.es;
import java.util.Scanner;
public class Alumno {
   private String nombre,apellido, DNI, correo;

Alumno(){
    this.nombre=" ";
    this.apellido=" ";
    this.DNI=" ";
    this.correo= " ";
}

    public Alumno(String nombre, String apellido, String DNI, String correo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.DNI = DNI;
        this.correo = correo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public void leervalores(){
    Scanner scanner=new Scanner(System.in);
    System.out.println("Inserte el nombre del alumno: ");
        this.nombre=scanner.next();
        System.out.println("Inserte el primer apellido del alumno: ");
        this.apellido=scanner.next();
        System.out.println("Inserte el DNI del alumno: ");
        this.DNI=scanner.next();
        System.out.println("Inserte el correo electronico del alumno: ");
        this.correo=scanner.next();

}
    public void mostrarpantalla(){
    System.out.println("Su nombre es:" + this.nombre +"Su apllido es"+ this.apellido + "Su DNI es: " +this.DNI + "Su correo es:" + this.correo);

    }
}
