package es.ujaen.es;

public class Practicas {
    private int id_pra;
    private int nota;
public Practicas(){
    this.nota=0;
    this.id_pra=0;

}

    public int getId_pra() {
        return id_pra;
    }

    public void setId_pra(int id_pra) {
        this.id_pra = id_pra;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
}
